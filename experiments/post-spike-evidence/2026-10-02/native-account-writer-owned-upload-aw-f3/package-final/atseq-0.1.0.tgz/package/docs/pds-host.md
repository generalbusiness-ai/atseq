# Local PDS host

S2 adds one local writer per application, two transport XRPC methods and exact
source retention. Application definitions are still opaque source objects in
this stage. S3 adds interpretation; S4 adds provisioning and interaction flows.

## Reproduce

Use Node 22.19 or later; the measured run uses 26.10.0. The local lease uses
[`node:sqlite`](https://nodejs.org/api/sqlite.html), available without an
experimental flag from 22.13. A native compiler may be needed for the official
PDS's SQLite package if that platform has no prebuilt binary.

```sh
npm run setup
npm run check
npm test
```

`npm test` includes the PDS gate. Use `npm run test:pds` to run just that gate.

The PDS gate starts the unmodified official `@atproto/pds` 0.5.31 with its real
HTTP APIs, repository storage and SQLite transactions. The local PLC uses the
official server with its in-memory test database, following the upstream
[development environment](https://github.com/bluesky-social/atproto/tree/main/packages/dev-env).
The test's PDS restarts preserve disk data while PLC stays alive. This does not
test a public PLC service, federation or PDS account migration.

Docker is not required. Missing packages or startup failure fail the gate;
there is no availability skip. Each run owns a new `.atseq-local/pds-*`
directory, marked with `ATSEQ_DISPOSABLE_PDS.json`, and a new `atseq-*.test`
account. Both services bind to loopback. Secrets stay in ignored files with
mode 0600 and are excluded from evidence. Tests remove the writer key/token file
on normal cleanup and leave the stopped PDS directory for inspection.
`resetDisposable` in `tests/support/pds/environment.mjs` accepts
only a marked directory directly under this checkout's `.atseq-local`, refuses
a running PDS, and accepts no remote URL or account. Close the test host first.

## Append and receipt

`provisionLog` writes genesis and head together and refuses to replace an
existing log. `Sequencer` acquires a local
SQLite exclusive lock and retains the last verified head in the same database.
This is an operational cache and process lease; application authors write no
SQL. Process death releases the kernel lock. The lease is local to one machine
and directory; it is not distributed failover or protection against copying
the sequencer private key to another host.

For each signed submission the writer reads and verifies a complete PDS
snapshot, checks retained retry identity, then conditionally writes one entry
and its head in a single `applyWrites` batch with `swapCommit`. A repository
commit reply must contain a valid CID and a nonempty revision. Provisioning and
append call an API that requires a valid swap CID at runtime; missing data
cannot silently turn either operation into an unconditional write. A repository
conflict or uncertain write response triggers reconciliation. A receipt is
returned only after observing the signed entry in verified persistent history.
Retrying the same unsigned content returns its original receipt, including
when a different valid signature represents that content. Reusing its nonce
for different content fails.

The test-only [`startSequencerService`](../tests/support/sequencer-service.ts) fixture
exposes loopback `ai.generalbusiness.atseq.submit` and
`ai.generalbusiness.atseq.receipt`, using the S1 Lexicons for inputs and outputs. It verifies
the app and genesis on receipt queries. S2 always reports `frontier: null` and
receipt lookup reports a pending outcome: ordering does not establish domain
effect. Unknown receipts return `Unavailable` with HTTP 404. Service and
transport uncertainty return HTTP 503; callers must retain the original signed
intent. Cross-origin access is not enabled. The application host provides the shared UI and agent transport with its
explicit signing flow. See [host access and limits](interaction.md#json-cli-adapter).

`readSnapshot` brackets reads with repository commit checks, verifies record
CIDs and the full position/predecessor chain, and rejects rollback or a changed
retained prefix. It follows actual PDS pagination but orders by signed position.
It requires no live notification to catch up. It does not verify the PDS's
repository CAR signature itself: its trust anchor is the pinned genesis plus
actor and sequencer proofs. PDS transport uses HTTPS except on loopback.

## Source retention

The authored [`ai.generalbusiness.atseq.source` Lexicon](../lexicons/ai/generalbusiness/atseq/source.json)
stores a content CID and an ordinary atproto blob reference. The record key is
the content CID. Source files use raw CIDs; canonical CBOR objects use their
CBOR CIDs and are stored as blob bytes. Reads verify the retention record CID,
Lexicon shape, raw blob hash and size, then the requested content CID. CBOR
objects also pass canonical wire verification. No remote URL discovery occurs.

The actual repository CAR includes source retention records, not the blobs.
Export must fetch and verify every source blob separately. Deleting the last
retention record can remove its blob immediately; restoring only the old
record then fails with `BlobNotFound`. Source repair is manual in S2.
`SourceStore.put` creates missing retention records but refuses an existing
record whose reference or blob is corrupt or unavailable. The tests act as an
operator: they upload retained bytes and restore references with standard PDS
APIs, or restore deliberately corrupted physical fixture files. The host does
not perform that repair automatically. Source closure and an archive format
remain S3 and S6 respectively.

## Bounds and limits

The host limits one response to 8 MiB for JSON, 512 KiB for source blobs and
128 MiB for a CAR. Snapshot listing stops at 20,000 records per collection and
rejects repeated cursors. Network calls time out after 15 seconds; a changing
repository or uncertain append has at most eight reconciliation attempts.
These are host operational limits, not new application schema contracts.

The host shares concurrent snapshot reads and reuses immutable verified history only while the repository commit CID is unchanged. Every changed commit requires full verification, including signatures, retry identity, fork and rollback checks. Appends therefore still take linear history work, giving quadratic total work over repeated growth. Receipt reads do not wait for the append queue. The current performance measurements are in [the README](../README.md).

The sequencer accepts entry 20,000 and refuses a new entry beyond that capacity with permanent `append_limit` before writing. Existing retries still return their original receipt, and the app remains readable. There is no per-app rate limit in this loopback prototype. A local process, including one run by another OS user, can consume the remaining capacity with valid distinct signed intents. Origin and Host checks block cross-origin browser requests; they do not authorize local processes. Do not expose this service beyond loopback. A shared deployment needs an operator-defined admission policy or per-app submit quota; the finite history bound alone is not such a policy.

The official PDS/PLC test packages have their own lockfile and are not Atseq
runtime dependencies. At this run, `npm audit` reports 11 vulnerable packages
in that isolated graph (8 high, 3 moderate); the root graph reports zero. The
test configuration has no SMTP delivery, MySQL database or public listener.
This is a disposable integration environment, not a deployment recipe. Its
unmodified upstream packages remain pinned so results can be reproduced.
`@atcute/car` 6.0.2, added to the root package for standard CAR reading, uses
the BSD Zero Clause license.

The disposable PDS child receives an explicit environment allowlist containing
only OS executable/temp paths, fixed `TZ=UTC`, disabled logging and
`OTEL_SDK_DISABLED=true`. It inherits no `OTEL_*` exporter settings, Jaeger
settings, `NODE_OPTIONS`, account/service configuration or caller credentials.
This controls fixture configuration; it does not sandbox network access.
For the pinned PDS library launch path, inherited OTLP/Jaeger settings alone do
not start a telemetry SDK. An inherited Node preload, such as `NODE_OPTIONS`
loading `@atproto/pds/telemetry`, can start it. The allowlist removes that preload
as well as exporter configuration; it does not rely on exporters being idle.

The pinned mock PLC runs in the test/development runner. Its library entry and
bundled dependencies do not start a telemetry SDK; the helper never mutates the
runner's global environment. Use an ordinary Node runner with no externally
preloaded telemetry instrumentation. If a caller preloads its own SDK or
instrumentation through `NODE_OPTIONS`, `--import`, `--require` or application
code, that caller must control its exporters before starting this runner. The
helper cannot disable an SDK already installed in the parent process.

`npm run dev:app` uses this same reference fixture. Keep both services on loopback
and use only synthetic accounts and test data. Never expose this demo fixture
publicly or use real accounts: it disables SSRF protection and rate limits and
retains local test state. This is separate from provisioning a production PDS.
The [telemetry results](../notes/2026-10-01-atseq-fixture-telemetry-results.md)
record the inherited-exporter regression and the precise runner boundary.

Only a PDS `RecordNotFound` response is classified as missing source. Other
PDS failures report `content_unavailable`; missing physical blobs are not
proof that a source retention record is absent. Hashes are checked before size
limits. SQLite writer leases report contention only for `SQLITE_BUSY`; corrupt
databases, permission failures and disk errors keep their original diagnostics.
