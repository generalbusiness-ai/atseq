/** A bounded data export built from an already verified query result. */
export interface ChartSource {
  app: string;
  genesis: string;
  definition: string;
  position: number;
  entry: string;
  query: string;
  params: unknown;
}
const escape = (value: unknown) =>
  String(value).replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[c]!,
  );
export function chartExport(rows: Record<string, unknown>[], label: string, value: string, source: ChartSource) {
  if (
    !rows.length ||
    rows.length > 100 ||
    rows.some(
      (row) =>
        !row ||
        typeof row[label] !== 'string' ||
        (row[label] as string).length > 120 ||
        !Number.isSafeInteger(row[value]),
    )
  )
    throw new Error('Choose 1–100 rows, a short text label and a safe integer value');
  const numbers = rows.map((row) => row[value] as number),
    min = Math.min(0, ...numbers),
    max = Math.max(0, ...numbers),
    span = max - min || 1;
  const x = (number: number) => 190 + ((number - min) / span) * 400,
    zero = x(0),
    height = rows.length * 28 + 96;
  const metadata = { format: 'atseq-static-query', version: 0, source, label, value, rows };
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="${height}" viewBox="0 0 800 ${height}" role="img" aria-labelledby="title desc"><title id="title">${escape(value)} by ${escape(label)}</title><desc id="desc">Zero-based horizontal bars. Verified source entry ${source.position}. Exact values are labeled.</desc><metadata>${escape(JSON.stringify(metadata))}</metadata><rect width="800" height="${height}" fill="white"/><g font-family="system-ui,sans-serif" font-size="13" fill="#24332f"><text x="16" y="24" font-size="17">${escape(value)} by ${escape(label)}</text><text x="${zero}" y="46" text-anchor="middle" fill="#68766f">0</text><line x1="${zero}" x2="${zero}" y1="51" y2="${height - 40}" stroke="#acb7b0"/>${rows
    .map((row, i) => {
      const y = 60 + i * 28,
        n = numbers[i]!,
        end = x(n);
      return `<text x="172" y="${y + 11}" text-anchor="end"><title>${escape(row[label])}</title>${escape(String(row[label]).length > 24 ? String(row[label]).slice(0, 23) + '…' : row[label])}</text><rect x="${Math.min(zero, end)}" y="${y}" width="${Math.abs(end - zero)}" height="15" fill="#527a68"/><text x="610" y="${y + 11}">${n}</text>`;
    })
    .join(
      '',
    )}<text x="16" y="${height - 15}" fill="#68766f">Verified entry ${source.position} · ${escape(source.query)} · source metadata embedded</text></g></svg>`;
  const html = `<!doctype html><html lang="en"><meta charset="utf-8"><title>${escape(value)} by ${escape(label)}</title><h1>${escape(value)} by ${escape(label)}</h1><p>Verified entry ${source.position}. This is a static retained query result.</p><table><thead><tr><th>${escape(label)}</th><th>${escape(value)}</th></tr></thead><tbody>${rows.map((row) => `<tr><td>${escape(row[label])}</td><td>${escape(row[value])}</td></tr>`).join('')}</tbody></table><details><summary>Source head and data</summary><pre>${escape(JSON.stringify(metadata, null, 2))}</pre></details></html>`;
  return { svg, html, metadata };
}
